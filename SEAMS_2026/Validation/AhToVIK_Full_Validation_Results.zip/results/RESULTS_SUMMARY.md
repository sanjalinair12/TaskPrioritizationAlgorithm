# AhToVIK full validation run — 22 October 2026

## Execution

Full settings: SMOKE=False; 500 runs per main static case, dynamic case, and knowledge-loop stream. Scalability: 500 seeds at N=10,30,100; 100 at 300; 40 at 1,000; 20 at 3,000; 15 at 10,000. Knowledge streams: eight episodes per sequence. All 15 supplied sanity checks passed.

Two execution fixes were required: (1) replace fork-based multiprocessing with joblib loky workers to avoid a solver/fork stall; (2) require every active role key to exist in the FILIPPONE backup team before dispatch, otherwise use its existing fallback. Algorithms, seeds, sample sizes, and scenario settings were otherwise retained. The source attachment is included unchanged; the executed notebook contains these two fixes. Completed caches were reused; the failed stress batch was rerun in full.

The output collector was also corrected to isolate its own variables from notebook variables. This did not change the experiments.

## Main dynamic results

| Method | On-time tasks (%) | Progress at deadline (%) | Mean recovery latency (simulation steps) | Repeated ineffective interventions per mission |
|---|---:|---:|---:|---:|
| RAINBOW | 92.37 | 98.70 | 10.847 | 0.1866 |
| ESFAHANI | 91.59 | 97.90 | 13.606 | 2.7590 |
| CARWEHL | 91.59 | 97.96 | 13.661 | 2.4436 |
| MARKET | 91.32 | 97.99 | 15.664 | 2.5706 |
| RODRIGUES | 90.95 | 97.96 | 13.014 | 1.6638 |
| CAMARA | 90.90 | 97.60 | 16.144 | 3.1642 |
| FILIPPONE | 90.74 | 97.68 | 12.395 | 3.1408 |
| AHTOVIK | 90.70 | 98.29 | 13.994 | 0.0268 |
| AHTOVIK-frozen | 90.70 | 98.29 | 13.994 | 0.0268 |
| AHTOVIK-nogate | 85.36 | 97.03 | 13.805 | 1.7814 |
| CALVO | 82.07 | 95.97 | 12.579 | 2.9886 |
| MAYYA | 79.64 | 95.46 | 10.241 | 1.5520 |

On-time rate is the share of tasks completed before the deadline, averaged across missions and scenarios; it is not the percentage of entirely successful missions. Recovery latency excludes missing values and uses simulated steps, not milliseconds.

## Dispatch checks across the full evaluation

| Batch | AhToVIK simulations | Dual-authority events | Duplicate dispatches | Flagged dispatches | Stale dispatches |
|---|---:|---:|---:|---:|---:|
| main | 5000 | 1 | 0 | 0 | 0 |
| sweeps | 8500 | 16 | 0 | 0 | 0 |
| sequences | 16000 | 0 | 0 | 0 | 0 |

The main benchmark contains a reproducible dual-authority event for AhToVIK in scenario `transient`, seed `128`. It was reproduced independently. The initial six-seed-per-scenario sanity check did not cover this case. A zero-conflict claim is therefore not supported. See `ahtovik_dispatch_violations.csv` for all affected cases.

## Knowledge loop

Means below cover episodes 2–7 (zero-indexed), after the first two episodes.

| Stream | AhToVIK recovery steps | Frozen recovery steps | Reduction versus frozen (%) | AhToVIK on-time tasks (%) |
|---|---:|---:|---:|---:|
| drift | 15.534 | 15.045 | -3.25 | 94.89 |
| nonrecurring | 16.476 | 16.727 | 1.50 | 94.68 |
| recurring | 14.887 | 19.952 | 25.39 | 94.22 |
| spurious | 15.567 | 14.352 | -8.47 | 94.99 |

## Static decision results

AhToVIK mean objective gap to CO-MILP: 7.42% (notebook bootstrap 95% interval 7.05–7.80%). All 500 core CO runs returned solver status 0. The objective measures differ from complete feasible team formation; this is not a certificate that the methods solve identical constrained problems.

At 0.8× supply, AhToVIK formed complete feasible teams for 51.5% of tasks versus 40.3% for CO-MILP; feasible individual-slot fill was 65.1% versus 68.2%. Thus the advantage depends on the metric.

## Interpretation limits

- These are synthetic simulation results from this notebook. Named related-work baselines are simplified mechanism-inspired implementations, not verified reproductions of the original systems.
- Wall-clock timings were collected in a shared container. Core/scarcity runs use parallel workers, and the abandoned fork attempt temporarily competed for CPU during early static runs. Treat latency and fitted scalability slopes as environment-dependent measurements, not publication-grade isolated timing evidence.
- The scalability sweep increases fleet size with a fixed task template count; it does not establish scaling under jointly increasing fleet and task demand.
- The recorded `makespan` field is implemented as mean task finish time (using the horizon for unfinished tasks), not the maximum finish time.
- The full-suite violation rows take precedence over the small sanity sample.
- Paired-test tables preserve the notebook’s Wilcoxon tests and Holm corrections; inspect effect sizes and scenario-level trade-offs before making superiority claims.

## Files

`results/` contains aggregate CSVs, figures, LaTeX scorecards, and raw CSVs. The executed notebook and full final execution log are included.

## Row counts

- dyn_main: 60,000
- dyn_seq: 80,000
- dyn_sweeps: 93,500
- static_core: 5,000
- static_determinism: 5,000
- static_robust_bigm: 2,000
- static_robust_v: 5,000
- static_scale: 13,400
- static_scarcity: 22,500
